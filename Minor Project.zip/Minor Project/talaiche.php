<?php
if(isset($_POST["submit"])){    
if(!empty($_POST['username']) && !empty($_POST['password'])) {    
    $username=$_POST['username'];    
    $password=$_POST['password'];    
    $con=mysql_connect('localhost','root','') or die(mysql_error());    
    mysql_select_db('keshav') or die("cannot select DB");    
    
    $query=mysql_query("SELECT * FROM basicinformation  WHERE username='".$username."'");    
    $numrows=mysql_num_rows($query);    
    if($numrows==0)    
    {    
    $sql="INSERT INTO basicinformation(username,password) VALUES('$username','$password')";    
    
    $result=mysql_query($sql);    
        if($result){    
    echo "Account Successfully Created";    
    } else {    
    echo "Failure!";    
    }    
    
    } else {    
    echo "That username already exists! Please try again with another.";    
    }    
    
} else {    
    echo "All fields are required!";    
}    
}    
?>    

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Basic Information Form</title>
    <style>
        *{
            margin: 0px;
            padding: 0px;
        }
        div{
            margin: auto;
            background-color: darkseagreen;
            text-align: center;
            height: 700px;
            padding: 15px;

        }
       form{
            display: inline-block;
            
        }
        form input{
            margin-top: 30px;
            text-align: center;
            height: 30px;
            width: 1000px;
            font-size: 25px;
            border: 2px solid black;
            border-radius: 30px;
            padding: 10px;
            color: black;
        }
        div form button{
            margin-top: 30px;
            font-size: 25px;
            border: 2px solid black;
            border-radius: 10px;
            padding: 7px;
            cursor: pointer;
        }
        div h1{
            font-size: 60px;
        }
        div form button:hover{
            border: 2px solid black;
           padding-right: 15px;
           padding-left: 15px;
            border-radius: 10px;
        }
        
    </style>
</head>
<body>
   
<div>
    <h1>Basic Information Form</h1>
    <form action="" method="post">
        <input type="text" name="username" >
        <input type ="password" name="password">
       <input type ="submit" name='submit'>

    </form>
    
</div>
    
   
</body>
</html>